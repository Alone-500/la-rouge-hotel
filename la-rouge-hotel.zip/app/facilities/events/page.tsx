'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { toast } from 'sonner'

export default function EventsPage(){
  const [f,setF]=useState({
    contact_name:'',email:'',phone:'',company_name:'',
    event_type:'Wedding', event_date:'', event_end_date:'', start_time:'', end_time:'',
    guest_count:50, setup_type:'Banquet',
    catering_required:false, av_equipment_needed:false, accommodation_required:false,
    rooms_needed:'', budget_range:'', message:''
  })
  const [loading,setLoading]=useState(false)

  async function submit(e:any){
    e.preventDefault()
    setLoading(true)
    const { error } = await supabase.from('event_enquiries').insert({
      contact_name:f.contact_name,
      email:f.email,
      phone:f.phone,
      event_type:f.event_type,
      event_date:f.event_date || null,
      guest_count:f.guest_count,
      message:[
        f.company_name && `Company: ${f.company_name}`,
        `Setup: ${f.setup_type}`,
        f.start_time && `Time: ${f.start_time}${f.end_time?' - '+f.end_time:''}`,
        f.catering_required && 'Catering: Yes',
        f.av_equipment_needed && 'AV: Yes',
        f.accommodation_required && `Rooms needed: ${f.rooms_needed||'TBD'}`,
        f.budget_range && `Budget: ${f.budget_range}`,
        f.message
      ].filter(Boolean).join('\n')
    })
    setLoading(false)
    if(error){ toast.error(error.message); return }
    toast.success('Enquiry sent! Our events team will contact you within 24 hours.')
    setF({...f, contact_name:'',email:'',phone:'',message:''})
  }

  const inputCls="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream text-sm outline-none focus:border-gold"
  const labCls="text-[10px] uppercase tracking-widest text-gold"

  return (
    <>
      <div className="pt-[74px]" />
      <section className="relative h-[44vh] min-h-[340px] flex items-end">
        <img src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=1600&q=80" className="absolute inset-0 w-full h-full object-cover" alt="" />
        <div className="absolute inset-0 bg-darkbg/72" />
        <div className="relative container-lr pb-10">
          <h1 className="font-serif text-[40px] md:text-[48px] text-cream">Event Spaces</h1>
          <p className="text-cream/80">Weddings • Conferences • Corporate Galas</p>
        </div>
      </section>

      <section className="container-lr py-16 grid lg:grid-cols-[1fr_1.2fr] gap-12">
        <div>
          <h2 className="font-serif text-[28px] text-cream mb-3">Host at La Rouge</h2>
          <p className="text-cream/78 leading-relaxed">Three configurable spaces: Grand Rouge Ballroom (280 guests), Camellia Salon (90), and the Rooftop Terrace (150 cocktail). In-house AV, sommelier-curated wine pairings, and dedicated event concierge.</p>
          <div className="mt-8 grid grid-cols-2 gap-4 text-sm">
            <img className="rounded-sm h-40 w-full object-cover" src="https://images.unsplash.com/photo-1505236858219-8359eb29e329?w=600" alt="" />
            <img className="rounded-sm h-40 w-full object-cover" src="https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=600" alt="" />
          </div>
        </div>

        <form onSubmit={submit} className="bg-darkcard border border-gold/15 rounded-sm p-7">
          <div className="text-gold text-[11px] uppercase tracking-widest mb-4">Event Enquiry</div>
          <div className="grid md:grid-cols-2 gap-4">
            {[
              ['contact_name','Contact name *', 'text', true],
              ['email','Email *','email', true],
              ['phone','Phone','tel', false],
              ['company_name','Company','text', false],
            ].map(([k,lab,type,req]:any)=>(
              <div key={k as string}>
                <label className={labCls}>{lab}</label>
                <input required={req} type={type} value={(f as any)[k]} onChange={e=>setF({...f,[k]:e.target.value})} className={inputCls}/>
              </div>
            ))}
            <div><label className={labCls}>Event type</label>
              <select value={f.event_type} onChange={e=>setF({...f,event_type:e.target.value})} className={inputCls}>
                {['Wedding','Conference','Birthday','Corporate','Other'].map(o=><option key={o}>{o}</option>)}
              </select>
            </div>
            <div><label className={labCls}>Event date *</label>
              <input type="date" required value={f.event_date} onChange={e=>setF({...f,event_date:e.target.value})} className={inputCls}/>
            </div>
            <div><label className={labCls}>End date</label>
              <input type="date" value={f.event_end_date} onChange={e=>setF({...f,event_end_date:e.target.value})} className={inputCls}/>
            </div>
            <div><label className={labCls}>Start time</label>
              <input type="time" value={f.start_time} onChange={e=>setF({...f,start_time:e.target.value})} className={inputCls}/>
            </div>
            <div><label className={labCls}>End time</label>
              <input type="time" value={f.end_time} onChange={e=>setF({...f,end_time:e.target.value})} className={inputCls}/>
            </div>
            <div><label className={labCls}>Expected guests *</label>
              <input type="number" required value={f.guest_count} onChange={e=>setF({...f,guest_count:Number(e.target.value)})} className={inputCls}/>
            </div>
            <div><label className={labCls}>Setup</label>
              <select value={f.setup_type} onChange={e=>setF({...f,setup_type:e.target.value})} className={inputCls}>
                {['Theatre','Banquet','Classroom','Cocktail','Boardroom'].map(o=><option key={o}>{o}</option>)}
              </select>
            </div>
            <div><label className={labCls}>Budget range</label>
              <input value={f.budget_range} onChange={e=>setF({...f,budget_range:e.target.value})} placeholder="$5,000 - $15,000" className={inputCls}/>
            </div>
            <div><label className={labCls}>Rooms needed</label>
              <input type="number" value={f.rooms_needed} onChange={e=>setF({...f,rooms_needed:e.target.value})} className={inputCls}/>
            </div>
          </div>
          <div className="flex flex-wrap gap-5 mt-4 text-sm text-cream/85">
            {[
              ['catering_required','Catering required'],
              ['av_equipment_needed','AV equipment needed'],
              ['accommodation_required','Accommodation required'],
            ].map(([k,lab])=>(
              <label key={k} className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={(f as any)[k]} onChange={e=>setF({...f,[k]:e.target.checked})} className="accent-[#D4AF37]" /> {lab}</label>
            ))}
          </div>
          <div className="mt-4"><label className={labCls}>Additional requirements</label>
            <textarea value={f.message} onChange={e=>setF({...f,message:e.target.value})} rows={4} className={inputCls} />
          </div>
          <button disabled={loading} className="btn-rouge w-full mt-5">{loading?'Sending…':'Send Enquiry'}</button>
        </form>
      </section>
    </>
  )
}
