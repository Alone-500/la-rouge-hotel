'use client'
import Link from 'next/link'

const facilities = [
  { slug:'bar', title:'Rouge Bar', desc:'Intimate cocktail lounge with craft mixology.', img:'https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=900' },
  { slug:'events', title:'Event Spaces', desc:'Bespoke venues for weddings, conferences & galas.', img:'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=900' },
  { slug:'', title:'Fine Dining', desc:'Seasonal tasting menus by our executive chef.', img:'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=900' },
  { slug:'', title:'Wellness Spa', desc:'Recovery suites, massage & steam rooms.', img:'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=900' },
]

export default function Facilities(){
  return (
    <>
      <div className="pt-[74px]" />
      <section className="bg-[#150707] border-b border-gold/12">
        <div className="container-lr py-16 text-center">
          <p className="text-gold text-[10px] tracking-[0.28em] uppercase">Hotel</p>
          <h1 className="font-serif text-[44px] text-cream mt-2">Facilities</h1>
          <div className="gold-divider w-16 mx-auto mt-4" />
        </div>
      </section>
      <section className="section-pad container-lr">
        <div className="grid md:grid-cols-2 gap-8">
          {facilities.map(f=>(
            <div key={f.title} className="group bg-darkcard border border-gold/12 rounded-sm overflow-hidden">
              <div className="h-[270px] overflow-hidden">
                <img src={f.img} alt={f.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
              </div>
              <div className="p-6">
                <h3 className="font-serif text-[24px] text-cream">{f.title}</h3>
                <p className="text-cream/72 text-sm mt-2 mb-4">{f.desc}</p>
                {f.slug ? <Link href={`/facilities/${f.slug}`} className="text-gold text-xs tracking-widest uppercase hover:text-gold-light">Explore →</Link> : <span className="text-cream/45 text-xs uppercase tracking-widest">Included with stay</span>}
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  )
}
