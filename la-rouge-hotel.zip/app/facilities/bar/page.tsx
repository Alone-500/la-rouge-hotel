export default function BarPage(){
  return (
    <>
      <div className="pt-[74px]" />
      <section className="relative h-[52vh] min-h-[380px] flex items-end">
        <img src="https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=1600&q=80" alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-darkbg/70" />
        <div className="relative container-lr pb-12">
          <p className="text-gold text-[10px] tracking-[0.28em] uppercase">Signature</p>
          <h1 className="font-serif text-[44px] text-cream">Rouge Bar</h1>
        </div>
      </section>
      <section className="container-lr py-16 grid lg:grid-cols-2 gap-12">
        <div>
          <h2 className="font-serif text-[30px] text-cream mb-4">An intimate haven</h2>
          <p className="text-cream/78 leading-relaxed">
            Deep velvet banquettes, brass detailing and a curated 180-bottle cellar. Our mixologists craft
            signature cocktails with house-infused spirits, smoked garnishes, and rare amari. Live jazz Thursday–Saturday.
          </p>
          <div className="gold-divider my-8" />
          <div className="grid sm:grid-cols-2 gap-6 text-sm text-cream/80">
            <div><div className="text-gold text-[10px] uppercase tracking-widest mb-1">Hours</div>Daily 17:00 – 01:00</div>
            <div><div className="text-gold text-[10px] uppercase tracking-widest mb-1">Dress Code</div>Smart Elegant</div>
          </div>
          <a href="https://wa.me/233302758820?text=Hello%20La%20Rouge%20Bar" target="_blank" rel="noreferrer" className="btn-rouge inline-block mt-8">WhatsApp Enquiries</a>
        </div>
        <div className="space-y-3">
          {['Negroni Rouge — Campari Reserve, sweet vermouth, orange zest','Smoked Old Fashioned — bourbon, rouge bitters','Gold Dust Martini — gin, dry vermouth, edible gold','Velvet Espresso — vodka, cold brew, cacao'].map(i=>(
            <div key={i} className="bg-darkcard border border-gold/12 px-5 py-4 rounded-sm text-cream/85 text-sm">{i}</div>
          ))}
          <p className="text-[11px] text-cream/50 mt-2">* Showcase only — bar is walk-in, no reservation required for hotel guests.</p>
        </div>
      </section>
    </>
  )
}
