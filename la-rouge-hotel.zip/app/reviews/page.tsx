'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { toast } from 'sonner'
import { Star } from 'lucide-react'

type Comment = { id:string, author_name:string, rating:number, comment:string, created_at:string }

function Stars({n}:{n:number}){ return <div className="flex gap-0.5 text-gold">{Array.from({length:5}).map((_,i)=><Star key={i} size={14} fill={i<n?'#D4AF37':'none'} />)}</div> }

export default function ReviewsPage(){
  const [comments,setComments]=useState<Comment[]>([])
  const [form,setForm]=useState({author_name:'',author_email:'',rating:5,comment:''})
  const [loading,setLoading]=useState(false)

  function load(){ supabase.from('site_comments').select('id,author_name,rating,comment,created_at').eq('is_approved',true).order('created_at',{ascending:false}).then(({data})=>setComments(data||[])) }
  useEffect(()=>{ load() },[])

  async function submit(e:any){
    e.preventDefault(); setLoading(true)
    const { error } = await supabase.from('site_comments').insert({...form, is_approved:false})
    setLoading(false)
    if(error){ toast.error(error.message); return }
    toast.success('Thank you! Your review is pending approval.')
    setForm({author_name:'',author_email:'',rating:5,comment:''})
  }

  return (
    <>
      <div className="pt-[74px]" />
      <section className="container-lr py-14">
        <h1 className="font-serif text-[40px] text-cream text-center">Guest Reviews</h1>
        <div className="gold-divider w-16 mx-auto mt-4" />
      </section>

      <section className="container-lr pb-8 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          {name:'Amara K.', stars:5, text:'Utterly flawless. The Presidential Suite is a masterpiece.'},
          {name:'James L.', stars:5, text:'Service was telepathic. Rouge Bar cocktails are world-class.'},
          {name:'Sofia R.', stars:5, text:'Dark, luxe, intimate. Felt like a movie set in the best way.'},
        ].map(r=>(
          <div key={r.name} className="bg-darkcard border border-gold/12 rounded-sm p-5">
            <Stars n={r.stars} />
            <p className="text-cream/82 text-sm mt-3 leading-relaxed">“{r.text}”</p>
            <div className="text-gold text-xs mt-3">— {r.name} · Google Reviews</div>
          </div>
        ))}
      </section>

      <section className="container-lr pb-16">
        <h2 className="font-serif text-[26px] text-cream mb-6">Verified guest comments</h2>
        <div className="grid md:grid-cols-2 gap-5">
          {comments.length===0 ? <div className="text-cream/60 text-sm">No approved comments yet. Be the first!</div> : comments.map(c=>(
            <div key={c.id} className="bg-darkcard border border-gold/10 rounded-sm p-5">
              <div className="flex items-center justify-between mb-2"><span className="text-cream font-medium">{c.author_name}</span><Stars n={c.rating}/></div>
              <p className="text-cream/80 text-sm leading-relaxed">{c.comment}</p>
              <div className="text-[11px] text-cream/45 mt-3">{new Date(c.created_at).toLocaleDateString()}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-[#150707] border-t border-gold/12">
        <div className="container-lr py-14 max-w-2xl">
          <h3 className="font-serif text-[26px] text-cream mb-5">Leave a review</h3>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <input required placeholder="Your name *" value={form.author_name} onChange={e=>setForm({...form,author_name:e.target.value})} className="bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream text-sm outline-none focus:border-gold"/>
              <input required type="email" placeholder="Email *" value={form.author_email} onChange={e=>setForm({...form,author_email:e.target.value})} className="bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream text-sm outline-none focus:border-gold"/>
            </div>
            <div className="flex items-center gap-3 text-cream/80 text-sm">
              Rating:
              {[1,2,3,4,5].map(s=>(
                <button type="button" key={s} onClick={()=>setForm({...form,rating:s})}><Star size={20} fill={s<=form.rating?'#D4AF37':'none'} className="text-gold"/></button>
              ))}
            </div>
            <textarea required placeholder="Your experience…" rows={4} value={form.comment} onChange={e=>setForm({...form,comment:e.target.value})} className="w-full bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream text-sm outline-none focus:border-gold"/>
            <button disabled={loading} className="btn-rouge">{loading?'Submitting…':'Submit Review'}</button>
            <p className="text-[11px] text-cream/50">Reviews are moderated before publishing. No account needed.</p>
          </form>
        </div>
      </section>
    </>
  )
}
