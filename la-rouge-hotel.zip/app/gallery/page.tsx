'use client'
import { useState } from 'react'

const cats = ['All','Rooms','Dining','Events','Exterior','Lobby'] as const
const photos = [
  {cat:'Rooms', src:'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=900'},
  {cat:'Rooms', src:'https://images.unsplash.com/photo-1566665797739-1674de7a421a?w=900'},
  {cat:'Rooms', src:'https://images.unsplash.com/photo-1591088398332-8a7791972843?w=900'},
  {cat:'Rooms', src:'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=900'},
  {cat:'Dining', src:'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=900'},
  {cat:'Dining', src:'https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=900'},
  {cat:'Events', src:'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=900'},
  {cat:'Events', src:'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=900'},
  {cat:'Lobby', src:'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=900'},
  {cat:'Exterior', src:'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=900'},
  {cat:'Lobby', src:'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=900'},
  {cat:'Dining', src:'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=900'},
]

export default function GalleryPage(){
  const [cat,setCat]=useState<typeof cats[number]>('All')
  const [light,setLight]=useState<string|null>(null)
  const list = cat==='All' ? photos : photos.filter(p=>p.cat===cat)
  return (
    <>
      <div className="pt-[74px]" />
      <section className="container-lr py-14 text-center">
        <h1 className="font-serif text-[42px] text-cream">Gallery</h1>
        <div className="gold-divider w-16 mx-auto mt-4" />
        <div className="flex flex-wrap justify-center gap-3 mt-8">
          {cats.map(c=>(
            <button key={c} onClick={()=>setCat(c)} className={`px-4 py-1.5 text-[11px] tracking-widest uppercase rounded-sm border transition ${cat===c ? 'border-gold text-gold bg-gold/8':'border-gold/25 text-cream/70 hover:text-gold'}`}>{c}</button>
          ))}
        </div>
      </section>
      <section className="container-lr pb-20">
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
          {list.map((p,i)=>(
            <img key={i} src={p.src} onClick={()=>setLight(p.src)} className="w-full rounded-sm cursor-zoom-in hover:opacity-90 transition border border-gold/10" alt="" />
          ))}
        </div>
      </section>
      {light && (
        <div onClick={()=>setLight(null)} className="fixed inset-0 z-[70] bg-black/90 flex items-center justify-center p-6">
          <img src={light} className="max-h-[86vh] max-w-[92vw] object-contain rounded-sm" alt="" />
        </div>
      )}
    </>
  )
}
