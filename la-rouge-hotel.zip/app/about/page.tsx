export default function AboutPage(){
  return (
    <>
      <div className="pt-[74px]" />
      <section className="relative h-[46vh] min-h-[340px] flex items-center">
        <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1600&q=80" alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-darkbg/78" />
        <div className="relative container-lr">
          <p className="text-gold text-[10px] tracking-[0.28em] uppercase">Our Story</p>
          <h1 className="font-serif text-[44px] text-cream">About La Rouge</h1>
        </div>
      </section>
      <section className="container-lr py-16 max-w-4xl">
        <h2 className="font-serif text-[30px] text-cream mb-4">A legacy built on uncompromising excellence</h2>
        <p className="text-cream/78 leading-relaxed mb-5">
          Founded in 2015, La Rouge Hotel was conceived as a counterpoint to conventional luxury — moody, intimate, cinematic. 
          Our signature deep-rouge palette, gold accents and tactile materials create a sanctuary that feels like a private members’ club.
        </p>
        <p className="text-cream/78 leading-relaxed mb-5">
          With just four meticulously curated room categories — Standard, Family, VIP Suite, and the legendary Presidential Suite —
          every guest receives deeply personal attention. Our 24-hour concierge, in-room sommelier service, and bespoke turn-down rituals
          redefine what a five-star stay can be.
        </p>
        <div className="gold-divider my-10" />
        <div className="grid sm:grid-cols-3 gap-8 text-center">
          <div><div className="font-serif text-[36px] text-gold">2015</div><div className="text-cream/70 text-sm">Founded</div></div>
          <div><div className="font-serif text-[36px] text-gold">5★</div><div className="text-cream/70 text-sm">Luxury Rated</div></div>
          <div><div className="font-serif text-[36px] text-gold">4.9</div><div className="text-cream/70 text-sm">Guest Score</div></div>
        </div>
      </section>
    </>
  )
}
