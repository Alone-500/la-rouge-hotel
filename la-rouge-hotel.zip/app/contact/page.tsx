'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { toast } from 'sonner'
import { MapPin, Phone, Mail } from 'lucide-react'

export default function ContactPage(){
  const [f,setF]=useState({full_name:'', email:'', phone:'', subject:'', message:''})
  const [loading,setLoading]=useState(false)
  async function submit(e:any){
    e.preventDefault()
    setLoading(true)
    const { error } = await supabase.from('contact_messages').insert(f)
    setLoading(false)
    if(error){ toast.error(error.message); return }
    toast.success('Message sent — we’ll reply within a few hours.')
    setF({full_name:'',email:'',phone:'',subject:'',message:''})
  }
  const ic='w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream text-sm outline-none focus:border-gold'
  const lb='text-[10px] uppercase tracking-widest text-gold'
  return (
    <>
      <div className="pt-[74px]" />
      <section className="container-lr py-14 grid lg:grid-cols-2 gap-12">
        <div>
          <h1 className="font-serif text-[40px] text-cream mb-3">Contact Us</h1>
          <p className="text-cream/75 mb-8">We’re here 24/7. Concierge, reservations, events.</p>
          <div className="space-y-4 text-cream/82">
            <div className="flex gap-3"><MapPin className="text-gold" size={18}/> 18 Rouge Avenue, Accra, Ghana</div>
            <div className="flex gap-3"><Phone className="text-gold" size={18}/> +233 30 275 8820</div>
            <div className="flex gap-3"><Mail className="text-gold" size={18}/> hello@larougehotel.com</div>
          </div>
          <div className="mt-8 rounded-sm overflow-hidden border border-gold/15">
            <iframe
              title="map"
              width="100%" height="260"
              style={{border:0, filter:'grayscale(1) invert(0.9)'}}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              src="https://www.google.com/maps?q=Accra%20Ghana&output=embed"
            />
          </div>
        </div>
        <form onSubmit={submit} className="bg-darkcard border border-gold/15 rounded-sm p-7 space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div><label className={lb}>Full name *</label><input required value={f.full_name} onChange={e=>setF({...f,full_name:e.target.value})} className={ic}/></div>
            <div><label className={lb}>Email *</label><input required type="email" value={f.email} onChange={e=>setF({...f,email:e.target.value})} className={ic}/></div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div><label className={lb}>Phone</label><input value={f.phone} onChange={e=>setF({...f,phone:e.target.value})} className={ic}/></div>
            <div><label className={lb}>Subject *</label><input required value={f.subject} onChange={e=>setF({...f,subject:e.target.value})} className={ic}/></div>
          </div>
          <div><label className={lb}>Message *</label><textarea required rows={5} value={f.message} onChange={e=>setF({...f,message:e.target.value})} className={ic}/></div>
          <button disabled={loading} className="btn-rouge w-full">{loading?'Sending…':'Send Message'}</button>
          <a href="https://wa.me/233302758820" target="_blank" rel="noreferrer" className="block text-center text-gold text-xs tracking-widest uppercase mt-2">or WhatsApp us directly →</a>
        </form>
      </section>
    </>
  )
}
