'use client'
import { useEffect, useState } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { supabase, RoomType } from '@/lib/supabase'

export default function BookingSearch(){
  const qp = useSearchParams()
  const router = useRouter()
  const [rooms,setRooms]=useState<RoomType[]>([])
  const [checkIn,setCheckIn]=useState('')
  const [checkOut,setCheckOut]=useState('')
  const [guests,setGuests]=useState(2)
  const [roomSlug,setRoomSlug]=useState(qp.get('room')||'')
  useEffect(()=>{ supabase.from('room_types').select('*').eq('is_active',true).order('base_price').then(({data})=>setRooms(data||[])) },[])
  useEffect(()=>{ const r=qp.get('room'); if(r) setRoomSlug(r)},[qp])

  const available = rooms.filter(r=> (!roomSlug || r.slug===roomSlug) && r.max_guests >= guests)

  function goDetails(room: RoomType){
    const params = new URLSearchParams({
      room_type_id: room.id,
      check_in: checkIn || new Date().toISOString().slice(0,10),
      check_out: checkOut || new Date(Date.now()+86400000*2).toISOString().slice(0,10),
      guests: String(guests)
    })
    router.push('/booking/details?'+params.toString())
  }

  return (
    <>
      <div className="pt-[74px]" />
      <section className="bg-[#150707] border-b border-gold/12">
        <div className="container-lr py-14">
          <h1 className="font-serif text-[36px] md:text-[44px] text-cream">Reserve Your Stay</h1>
          <p className="text-cream/70 mt-2">Instant confirmation • Pay at the hotel</p>
        </div>
      </section>
      <section className="container-lr py-10">
        <div className="bg-darkcard border border-gold/15 rounded-sm p-6 grid md:grid-cols-5 gap-4">
          <div>
            <label className="text-[10px] tracking-widest uppercase text-gold">Check-in</label>
            <input type="date" value={checkIn} onChange={e=>setCheckIn(e.target.value)} className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-2.5 text-cream text-sm outline-none focus:border-gold"/>
          </div>
          <div>
            <label className="text-[10px] tracking-widest uppercase text-gold">Check-out</label>
            <input type="date" value={checkOut} onChange={e=>setCheckOut(e.target.value)} className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-2.5 text-cream text-sm outline-none focus:border-gold"/>
          </div>
          <div>
            <label className="text-[10px] tracking-widest uppercase text-gold">Guests</label>
            <select value={guests} onChange={e=>setGuests(Number(e.target.value))} className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-2.5 text-cream text-sm outline-none focus:border-gold">
              {[1,2,3,4].map(n=><option key={n} value={n}>{n}</option>)}
            </select>
          </div>
          <div>
            <label className="text-[10px] tracking-widest uppercase text-gold">Room</label>
            <select value={roomSlug} onChange={e=>setRoomSlug(e.target.value)} className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-2.5 text-cream text-sm outline-none focus:border-gold">
              <option value="">Any</option>
              {rooms.map(r=><option key={r.id} value={r.slug}>{r.name}</option>)}
            </select>
          </div>
          <div className="flex items-end">
            <button className="btn-rouge w-full" onClick={()=>{/* search already reactive */}}>Search</button>
          </div>
        </div>

        <div className="mt-10 grid md:grid-cols-2 gap-6">
          {available.map(r=>{
            const nights = checkIn && checkOut ? Math.max(1, Math.round((+new Date(checkOut)-+new Date(checkIn))/86400000)) : 2
            return (
              <div key={r.id} className="bg-darkcard border border-gold/12 rounded-sm overflow-hidden flex">
                <img src={r.image_url||''} className="w-[190px] object-cover hidden sm:block" alt="" />
                <div className="p-5 flex-1 flex flex-col">
                  <div className="font-serif text-[20px] text-cream">{r.name}</div>
                  <div className="text-cream/70 text-sm mt-1">{r.description}</div>
                  <div className="mt-auto pt-4 flex items-end justify-between">
                    <div>
                      <div className="text-gold text-xl font-serif">${r.base_price}<span className="text-xs text-cream/60"> /nt</span></div>
                      <div className="text-[11px] text-cream/55">{nights} night{nights>1?'s':''} · ${(r.base_price*nights).toLocaleString()} total</div>
                    </div>
                    <button onClick={()=>goDetails(r)} className="text-[11px] tracking-widest uppercase text-gold border border-gold/40 px-4 py-2 rounded-sm hover:bg-gold/10">Select</button>
                  </div>
                </div>
              </div>
            )
          })}
          {available.length===0 && <div className="text-cream/60">No rooms match your criteria.</div>}
        </div>
      </section>
    </>
  )
}
