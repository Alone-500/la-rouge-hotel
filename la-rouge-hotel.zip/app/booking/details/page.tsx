'use client'
import { useSearchParams, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { toast } from 'sonner'

export default function BookingDetails(){
  const qp = useSearchParams()
  const router = useRouter()
  const [loading,setLoading]=useState(false)
  const [form,setForm]=useState({
    guest_name:'',
    guest_email:'',
    guest_phone:'',
    special_requests:''
  })
  const room_type_id = qp.get('room_type_id')||''
  const check_in = qp.get('check_in')||''
  const check_out = qp.get('check_out')||''
  const guests = Number(qp.get('guests')||2)
  const [room,setRoom]=useState<any>(null)

  useEffect(()=>{ if(room_type_id) supabase.from('room_types').select('*').eq('id',room_type_id).single().then(({data})=>setRoom(data)) },[room_type_id])

  async function submit(e:any){
    e.preventDefault()
    if(!form.guest_name || !form.guest_email || !form.guest_phone){ toast.error('Fill all required fields'); return }
    setLoading(true)
    const payload = {
      guest_name: form.guest_name,
      guest_email: form.guest_email,
      guest_phone: form.guest_phone,
      check_in_date: check_in,
      check_out_date: check_out,
      room_type_id,
      num_guests: guests,
      special_requests: form.special_requests || null,
      status: 'confirmed'
    }
    const { data, error } = await supabase.from('bookings').insert(payload).select('booking_reference').single()
    setLoading(false)
    if(error){ toast.error(error.message); return }
    router.push(`/booking/confirmation?ref=${data.booking_reference}`)
  }

  const nights = check_in && check_out ? Math.max(1, Math.round((+new Date(check_out)-+new Date(check_in))/86400000)) : 2
  const total = room ? room.base_price * nights : 0

  return (
    <>
      <div className="pt-[74px]" />
      <div className="container-lr py-12 grid lg:grid-cols-3 gap-10">
        <form onSubmit={submit} className="lg:col-span-2 bg-darkcard border border-gold/15 rounded-sm p-7 space-y-5">
          <h1 className="font-serif text-[30px] text-cream">Guest Details</h1>
          <p className="text-cream/65 text-sm">Step 3 of 4 — No payment online, pay at hotel.</p>
          <div className="grid md:grid-cols-2 gap-5">
            <div><label className="text-[10px] uppercase tracking-widest text-gold">Full name *</label>
              <input required value={form.guest_name} onChange={e=>setForm({...form,guest_name:e.target.value})}
                className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream outline-none focus:border-gold"/>
            </div>
            <div><label className="text-[10px] uppercase tracking-widest text-gold">Email *</label>
              <input type="email" required value={form.guest_email} onChange={e=>setForm({...form,guest_email:e.target.value})}
                className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream outline-none focus:border-gold"/>
            </div>
            <div><label className="text-[10px] uppercase tracking-widest text-gold">Phone *</label>
              <input required value={form.guest_phone} onChange={e=>setForm({...form,guest_phone:e.target.value})}
                className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream outline-none focus:border-gold"/>
            </div>
            <div><label className="text-[10px] uppercase tracking-widest text-gold">Guests</label>
              <input readOnly value={guests} className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream/80"/>
            </div>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-widest text-gold">Special requests (optional)</label>
            <textarea value={form.special_requests} onChange={e=>setForm({...form,special_requests:e.target.value})}
              rows={4} className="w-full mt-1 bg-[#120606] border border-gold/20 rounded-sm px-3 py-3 text-cream outline-none focus:border-gold"/>
          </div>
          <button disabled={loading} className="btn-rouge w-full">{loading?'Processing…':'Confirm Booking'}</button>
        </form>

        <aside className="bg-darkcard border border-gold/15 rounded-sm p-6 h-fit">
          <div className="text-[11px] tracking-widest uppercase text-gold mb-2">Your stay</div>
          <div className="font-serif text-[22px] text-cream mb-3">{room?.name || 'Loading…'}</div>
          <div className="text-sm text-cream/80 space-y-2">
            <div>Check-in: <b>{check_in}</b></div>
            <div>Check-out: <b>{check_out}</b></div>
            <div>Guests: <b>{guests}</b></div>
            <div>Nights: <b>{nights}</b></div>
          </div>
          <div className="gold-divider my-4" />
          <div className="flex justify-between text-cream"><span>Total</span><span className="text-gold text-xl font-serif">${total.toLocaleString()}</span></div>
          <p className="text-[11px] text-cream/55 mt-3">Pay at hotel. Instant confirmation. Free cancellation 48h prior.</p>
        </aside>
      </div>
    </>
  )
}
