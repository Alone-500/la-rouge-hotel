'use client'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { CheckCircle2 } from 'lucide-react'

export default function Confirmation(){
  const ref = useSearchParams().get('ref') || 'LR-XXXXX'
  return (
    <>
      <div className="pt-[74px]" />
      <div className="container-lr py-20 text-center max-w-2xl mx-auto">
        <CheckCircle2 size={56} className="text-gold mx-auto mb-5" />
        <h1 className="font-serif text-[38px] text-cream mb-3">Booking Confirmed</h1>
        <p className="text-cream/75 mb-8">Thank you. Your reservation is confirmed.</p>
        <div className="bg-darkcard border border-gold/20 rounded-sm p-8">
          <div className="text-[10px] uppercase tracking-widest text-gold mb-2">Booking reference</div>
          <div className="font-serif text-[30px] text-cream tracking-wider">{ref}</div>
          <div className="gold-divider my-6" />
          <p className="text-cream/75 text-sm">A confirmation has been sent to your email. Pay at the hotel upon arrival. We look forward to welcoming you to La Rouge.</p>
        </div>
        <div className="mt-8 flex gap-4 justify-center">
          <Link href="/" className="btn-outline-gold">Back Home</Link>
          <Link href="/rooms" className="btn-rouge">Explore More</Link>
        </div>
      </div>
    </>
  )
}
