'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { supabase, RoomType } from '@/lib/supabase'
import RoomCard from '@/components/RoomCard'
import { UtensilsCrossed, Wine, Wifi, Car } from 'lucide-react'
import { motion } from 'framer-motion'

export default function HomePage() {
  const [rooms, setRooms] = useState<RoomType[]>([])

  useEffect(() => {
    supabase.from('room_types').select('*').eq('is_active', true).order('base_price', {ascending: true})
      .then(({data})=> setRooms(data || []))
  }, [])

  return (
    <>
      {/* HERO */}
      <section className="relative h-[100vh] min-h-[680px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1600&q=80"
            alt="La Rouge Hotel"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-darkbg via-darkbg/70 to-darkbg/40" />
          <div className="absolute inset-0 bg-rouge/10 mix-blend-multiply" />
        </div>
        <motion.div 
          initial={{opacity:0, y:30}}
          animate={{opacity:1, y:0}}
          transition={{duration:1, delay:0.2}}
          className="relative z-10 text-center px-6 max-w-4xl"
        >
          <p className="text-gold text-[11px] md:text-[12px] tracking-[0.35em] uppercase mb-5">Welcome to</p>
          <h1 className="font-serif text-[46px] md:text-[84px] leading-[0.95] text-cream mb-4">
            La Rouge<br/>
            <span className="italic text-gold">Hotel</span>
          </h1>
          <div className="gold-divider w-24 mx-auto my-6" />
          <p className="text-cream/80 text-[15px] md:text-[17px] max-w-xl mx-auto leading-relaxed mb-10">
            Where timeless elegance meets uncompromising luxury. An intimate 5-star sanctuary in the heart of the city.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/booking" className="btn-rouge">Reserve Your Stay</Link>
            <Link href="/rooms" className="btn-outline-gold">Explore Suites</Link>
          </div>
        </motion.div>
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-cream/40 text-[10px] tracking-widest uppercase">
          Scroll
        </div>
      </section>

      {/* WELCOME */}
      <section className="section-pad bg-darkbg">
        <div className="container-lr max-w-4xl text-center">
          <p className="text-gold text-[10px] tracking-[0.28em] uppercase mb-4">A Legacy of Excellence</p>
          <h2 className="font-serif text-[34px] md:text-[46px] text-cream leading-tight mb-6">
            A sanctuary of <em className="text-gold italic">refined luxury</em><br/>and impeccable service
          </h2>
          <div className="gold-divider w-20 mx-auto my-7" />
          <p className="text-cream/75 text-[15.5px] leading-relaxed max-w-2xl mx-auto">
            La Rouge Hotel redefines five-star hospitality with 4 exquisitely curated room categories, 
            a world-class culinary bar, bespoke event spaces, and a commitment to excellence that 
            transforms every stay into an unforgettable memory.
          </p>
        </div>
      </section>

      {/* FEATURED ROOMS */}
      <section className="section-pad bg-[#150707]">
        <div className="container-lr">
          <div className="text-center mb-12">
            <p className="text-gold text-[10px] tracking-[0.28em] uppercase mb-3">Accommodation</p>
            <h2 className="font-serif text-[34px] md:text-[44px] text-cream">Rooms & Suites</h2>
            <div className="gold-divider w-16 mx-auto mt-5" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-7">
            {rooms.map(r => <RoomCard key={r.id} room={r} />)}
          </div>
          <div className="text-center mt-12">
            <Link href="/rooms" className="btn-outline-gold inline-block">View All Rooms</Link>
          </div>
        </div>
      </section>

      {/* AMENITIES */}
      <section className="section-pad">
        <div className="container-lr">
          <div className="text-center mb-14">
            <p className="text-gold text-[10px] tracking-[0.28em] uppercase mb-3">Signature Experiences</p>
            <h2 className="font-serif text-[34px] md:text-[42px] text-cream">Unparalleled Amenities</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
            {[
              {Icon: UtensilsCrossed, title:'Fine Dining', desc:'Michelin-inspired cuisine with seasonal tasting menus.'},
              {Icon: Wine, title:'Rouge Bar', desc:'Craft cocktails & curated wines in an intimate lounge.'},
              {Icon: Wifi, title:'High-Speed WiFi', desc:'Complimentary ultra-fast connectivity throughout.'},
              {Icon: Car, title:'Valet & Parking', desc:'24/7 valet service and secure private parking.'},
            ].map(a=>(
              <div key={a.title} className="text-center">
                <div className="w-14 h-14 mx-auto mb-4 rounded-full border border-gold/30 flex items-center justify-center">
                  <a.Icon size={22} className="text-gold" />
                </div>
                <h4 className="font-serif text-[19px] text-cream mb-2">{a.title}</h4>
                <p className="text-cream/65 text-sm leading-relaxed">{a.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-28">
        <div className="absolute inset-0">
          <img src="https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1600&q=80" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-darkbg/85" />
        </div>
        <div className="relative container-lr text-center max-w-3xl">
          <h2 className="font-serif text-[36px] md:text-[50px] text-cream mb-4">Your extraordinary stay awaits</h2>
          <p className="text-cream/75 mb-9">Instant confirmation • Pay at the hotel • Complimentary upgrade subject to availability</p>
          <Link href="/booking" className="btn-rouge">Book Now</Link>
        </div>
      </section>
    </>
  )
}
