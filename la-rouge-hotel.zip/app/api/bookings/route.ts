import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest){
  // bookings are inserted directly via supabase client (RLS allows)
  // this route exists for blueprint completeness + future Resend email
  const body = await req.json()
  return NextResponse.json({ ok:true, received: body })
}
