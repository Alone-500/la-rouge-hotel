'use client'
import { useEffect, useState } from 'react'
import { supabase, RoomType } from '@/lib/supabase'
import RoomCard from '@/components/RoomCard'

export default function RoomsPage(){
  const [rooms,setRooms]=useState<RoomType[]>([])
  useEffect(()=>{ supabase.from('room_types').select('*').eq('is_active',true).order('base_price').then(({data})=>setRooms(data||[])) },[])
  return (
    <>
      <section className="pt-[150px] pb-14 relative">
        <div className="absolute inset-0">
          <img src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=1600&q=80" className="w-full h-full object-cover" alt="" />
          <div className="absolute inset-0 bg-darkbg/80" />
        </div>
        <div className="relative container-lr text-center">
          <p className="text-gold text-[10px] tracking-[0.28em] uppercase">Accommodation</p>
          <h1 className="font-serif text-[40px] md:text-[54px] text-cream mt-2">Rooms & Suites</h1>
          <div className="gold-divider w-16 mx-auto mt-4" />
        </div>
      </section>
      <section className="section-pad">
        <div className="container-lr grid md:grid-cols-2 gap-8">
          {rooms.map(r=> <RoomCard key={r.id} room={r} />)}
        </div>
      </section>
    </>
  )
}
